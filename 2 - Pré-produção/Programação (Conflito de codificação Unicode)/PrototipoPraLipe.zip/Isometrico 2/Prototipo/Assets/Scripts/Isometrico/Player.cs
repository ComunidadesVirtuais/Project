﻿/// <summary>
/// Player.cs
///  Plataforma movel.cs
/// Created in 10/09/2014
/// Descrição: Classe reponsavel pela movimentaçao do player para Desktop
///				Atraves dele e possivel controlar as animaçoes de correr e pular
/// </summary>


using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour {
	
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
	}
}