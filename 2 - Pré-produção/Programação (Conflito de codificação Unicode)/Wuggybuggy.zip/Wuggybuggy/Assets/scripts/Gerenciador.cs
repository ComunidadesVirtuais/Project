﻿using UnityEngine;
using System.Collections;

public class Gerenciador : MonoBehaviour {

	private bool emJogo = true;
	public float qtdMovimento = 0.5f;
	public float velocidadeVolta = 0.5f;
	public float resistenciaPorDistancia;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	public bool EstaEmJogo()
	{
		return emJogo;
	}

	public void FinalizarJogo()
	{
		emJogo = false;
		// fazer oq tiver de fazer no final
	}
}
