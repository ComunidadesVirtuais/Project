﻿using UnityEngine;
using System.Collections;

public class EventManager : MonoBehaviour
{

	public string cena;
	public bool habilitado = true;

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}

	void OnTriggerEnter2D(Collider2D colisor)
	{

		if((colisor.gameObject.name == "player") && habilitado)
		{
			colisor.gameObject.transform.position = new Vector3(colisor.transform.position.x - 0.2f, colisor.transform.position.y + 0.2f, colisor.transform.position.z);
			GameObject.Find ("CaixaDialogo").GetComponent<LoadXmlData>().Save();
			Application.LoadLevel(cena);
		}
	}

	public void MudarCena(string pCena, string habilitar)
	{
		cena = pCena;

		bool valor = (habilitar == "true");
		Habilitar (valor);
	}

	public void Habilitar(bool valor)
	{
		habilitado = valor;
	}
}
