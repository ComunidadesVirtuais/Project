﻿using UnityEngine;
using System.Collections;

public class ItemHp : MonoBehaviour {

	private Collider2D collider = null;

	private float pixelInsetX = 0;
	private float pixelInsetInicial = 0;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if(this.guiTexture.pixelInset.x != pixelInsetInicial) pixelInsetX = this.guiTexture.pixelInset.x;
	}

	void OnMouseDown()
	{
		pixelInsetInicial = this.guiTexture.pixelInset.x;
	}

	void OnMouseUp()
	{
		//if(collider != null && collider.gameObject.name == "player") print ("vou adicionar uma vida!"); 
		float esquerda = Screen.width / 2 - this.guiTexture.pixelInset.width/2;
		float direita = Screen.width / 2;

		print (pixelInsetX + " " + esquerda + " " + direita);
		if((pixelInsetX > esquerda) && (pixelInsetX < direita))
		{
			bool adicionou = GameObject.Find ("Vidas").GetComponent<Life> ().addVidas (false);
			if(adicionou) Destroy (this.gameObject);
		}
		else print ("fora");
	}
}
