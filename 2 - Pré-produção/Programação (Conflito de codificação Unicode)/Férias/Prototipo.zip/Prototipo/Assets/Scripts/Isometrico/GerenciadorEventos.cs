﻿using UnityEngine;
using System.Collections;

public class GerenciadorEventos : MonoBehaviour {

	// Use this for initialization
	void Start ()
	{
		if (PlayerPrefs.HasKey ("Eventos") && DataManager.loadEventos)
		{
			string save = PlayerPrefs.GetString ("Eventos");
			string[] eventos = save.Split(';');
			
			for(int i =0; i < eventos.Length; i++)
			{
				string[] infoEvento = eventos[i].Split (',');
				GameObject.Find (infoEvento[0]).GetComponent<EventManager>().MudarCena(infoEvento[2], infoEvento[1]);
			}
		}
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
