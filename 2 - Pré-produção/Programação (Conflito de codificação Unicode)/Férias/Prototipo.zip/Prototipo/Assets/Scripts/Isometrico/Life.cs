﻿using UnityEngine;
using System.Collections;

public class Life : MonoBehaviour {
	
	public Texture2D[] vidaAtual;
	
	public int maxVidas = 3;
	private int qtdVidas = 3;
	public float tempoDecrescimo = 20.0f;

	public string itemHP = "itemHP";

	// Use this for initialization
	void Start () {
		InvokeRepeating("ContarTempo", tempoDecrescimo, tempoDecrescimo);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	
	public void excluirVidas()
	{
		if(qtdVidas > 1)
		{
			qtdVidas --;
			guiTexture.texture = vidaAtual [qtdVidas-1];
		}
		else
		{
			print ("Game over!");
			DataManager.gameOver = true;
			GameObject.Find ("CaixaDialogo").GetComponent<LoadXmlData>().Save();
			Application.LoadLevel(Application.loadedLevel);

		}
	}

	public bool addVidas(bool addInventario = true)
	{
		if(qtdVidas < maxVidas)
		{	
			qtdVidas ++;
			guiTexture.texture = vidaAtual [qtdVidas - 1];
			return true;
		}
		else
		{
			if(addInventario)
			{
				print ("Vai coletar: " + itemHP);
				GameObject.Find ("Inventario").GetComponent<Inventory>().ColetarItem(itemHP);

			}
			return false;
		}
	}

	public int GetQtdVidas()
	{
		return qtdVidas;
	}

	public void SetQtdVidas(int value)
	{
		qtdVidas = value;
		guiTexture.texture = vidaAtual [qtdVidas - 1];
	}

	private void ContarTempo()
	{
		excluirVidas ();
	}
}
