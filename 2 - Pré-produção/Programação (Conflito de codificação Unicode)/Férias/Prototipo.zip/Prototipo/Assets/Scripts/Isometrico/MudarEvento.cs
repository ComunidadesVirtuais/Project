﻿using UnityEngine;
using System.Collections;

public class MudarEvento : MonoBehaviour {

	public string nomeObjeto;
	public string nomeCena;
	public string habilitarEvento;

	public bool desabilitarEste;

	// Use this for initialization
	void Start ()
	{
		string newSave = "";
		bool achou = false;

		if (PlayerPrefs.HasKey ("Eventos"))
		{
			string save = PlayerPrefs.GetString ("Eventos");
			string[] eventos = save.Split(';');

			for(int i =0; i < eventos.Length; i++)
			{
				string[] infoEvento = eventos[i].Split (',');
				if(infoEvento[0] == nomeObjeto)
				{
					achou = true;
					newSave += nomeObjeto + "," +  habilitarEvento + "," + nomeCena;
				}
				else newSave += eventos[i];
				
				if(i < eventos.Length - 1) newSave += ";";
			}
			if(!achou) newSave += ";" + nomeObjeto + "," +  habilitarEvento + "," + nomeCena;
		}
		else newSave += nomeObjeto + "," +  habilitarEvento + "," + nomeCena;

		PlayerPrefs.SetString("Eventos", newSave);
		PlayerPrefs.Save ();

		DataManager.loadEventos = true;
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
